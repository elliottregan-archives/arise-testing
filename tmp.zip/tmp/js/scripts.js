$(document).ready(function() {
  var menuTimeouts, showMenuItem;
  menuTimeouts = [];
  $(':not(.mobile_sidebar) .has_submenu').on({
    mouseenter: function() {
      var menuItem;
      console.log("mouseon");
      menuItem = $(this);
      $(this).siblings('.header_link').addClass('fade');
      $(this).children('.submenu').addClass('visuallyHidden');
      setTimeout((function() {
        return menuItem.children('.submenu').addClass('visible');
      }), 40);
      return menuItem.children('.submenu').children('.header_link').each(function(i) {
        return showMenuItem($(this), i);
      });
    },
    mouseleave: function() {
      var menuItem;
      console.log("mouseoff");
      menuItem = $(this);
      $(this).children('.submenu').removeClass('visible');
      $(this).children('.submenu').children('.header_link').removeClass('visible');
      $(this).siblings('.header_link').removeClass('fade');
      return setTimeout((function() {
        return menuItem.children('.submenu').removeClass('visuallyHidden');
      }), 10);
    }
  });
  showMenuItem = function(header_link, n) {
    return menuTimeouts[n] = window.setInterval((function() {
      return header_link.addClass('visible');
    }), 150 + 40 * n);
  };
  return $('.sidebar_toggle').on('click', function(e) {
    e.preventDefault();
    $(this).siblings('.arrow_divider').toggleClass('to_the_right');
    return $('.slideaway_wrapper').toggleClass('slide_away');
  });
});
